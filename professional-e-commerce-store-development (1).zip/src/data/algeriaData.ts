export interface WilayaData {
  code: string;
  name: string;
  nameAr: string;
  shippingZone: 'capital' | 'north' | 'highland' | 'south';
  dairas: { name: string; nameAr: string; communes: { name: string; nameAr: string }[] }[];
}

export const SHIPPING_COSTS: Record<string, number> = { capital: 300, north: 500, highland: 600, south: 800 };
export const SHIPPING_LABELS: Record<string, string> = { capital: 'الجزائر العاصمة وضواحيها', north: 'الشمال', highland: 'الهضاب العليا', south: 'الجنوب' };

export const wilayas: WilayaData[] = [
  { code:'01', name:'Adrar', nameAr:'أدرار', shippingZone:'south', dairas:[
    { name:'Adrar', nameAr:'أدرار', communes:[{name:'Adrar',nameAr:'أدرار'},{name:'Timmi',nameAr:'تيمي'},{name:'Bouda',nameAr:'بودة'},{name:'Ouled Ahmed Timmi',nameAr:'أولاد أحمد تيمي'}] },
    { name:'Reggane', nameAr:'رقان', communes:[{name:'Reggane',nameAr:'رقان'},{name:'Sali',nameAr:'سالي'}] },
    { name:'Aoulef', nameAr:'أولف', communes:[{name:'Aoulef',nameAr:'أولف'},{name:'Timokten',nameAr:'تيمقطن'}] },
    { name:'Timimoun', nameAr:'تيميمون', communes:[{name:'Timimoun',nameAr:'تيميمون'},{name:'Ouled Said',nameAr:'أولاد سعيد'},{name:'Aougrout',nameAr:'أوقروت'},{name:'Tinerkouk',nameAr:'تينركوك'}] },
    { name:'Fenoughil', nameAr:'فنوغيل', communes:[{name:'Fenoughil',nameAr:'فنوغيل'},{name:'Tit',nameAr:'تيت'},{name:'Zaouiet Kounta',nameAr:'زاوية كنتة'}] },
    { name:'Tsabit', nameAr:'تسابيت', communes:[{name:'Tsabit',nameAr:'تسابيت'},{name:'Tamest',nameAr:'تامست'}] },
  ]},
  { code:'02', name:'Chlef', nameAr:'الشلف', shippingZone:'north', dairas:[
    { name:'Chlef', nameAr:'الشلف', communes:[{name:'Chlef',nameAr:'الشلف'},{name:'Sendjas',nameAr:'سنجاس'},{name:'Oum Drou',nameAr:'أم الذروع'}] },
    { name:'Ténès', nameAr:'تنس', communes:[{name:'Ténès',nameAr:'تنس'},{name:'Sidi Akkacha',nameAr:'سيدي عكاشة'},{name:'El Marsa',nameAr:'المرسى'}] },
    { name:'Boukadir', nameAr:'بوقادير', communes:[{name:'Boukadir',nameAr:'بوقادير'},{name:'Ouled Fares',nameAr:'أولاد فارس'},{name:'Sobha',nameAr:'صبحة'}] },
    { name:'Ain Merane', nameAr:'عين مران', communes:[{name:'Ain Merane',nameAr:'عين مران'},{name:'Oued Sly',nameAr:'وادي سلي'}] },
    { name:'El Karimia', nameAr:'الكريمية', communes:[{name:'El Karimia',nameAr:'الكريمية'},{name:'Tadjena',nameAr:'تاجنة'}] },
  ]},
  { code:'03', name:'Laghouat', nameAr:'الأغواط', shippingZone:'highland', dairas:[
    { name:'Laghouat', nameAr:'الأغواط', communes:[{name:'Laghouat',nameAr:'الأغواط'},{name:'Ksar El Hirane',nameAr:'قصر الحيران'},{name:'El Assafia',nameAr:'العسافية'}] },
    { name:'Aflou', nameAr:'أفلو', communes:[{name:'Aflou',nameAr:'أفلو'},{name:'Oued Morra',nameAr:'وادي مرة'}] },
    { name:'Brida', nameAr:'بريدة', communes:[{name:'Brida',nameAr:'بريدة'},{name:'Hassi Delaa',nameAr:'حاسي الدلاعة'}] },
    { name:'Hassi R\'mel', nameAr:'حاسي الرمل', communes:[{name:'Hassi R\'mel',nameAr:'حاسي الرمل'}] },
    { name:'Ain Mahdi', nameAr:'عين ماضي', communes:[{name:'Ain Mahdi',nameAr:'عين ماضي'},{name:'Tadjrouna',nameAr:'تاجرونة'}] },
  ]},
  { code:'04', name:'Oum El Bouaghi', nameAr:'أم البواقي', shippingZone:'highland', dairas:[
    { name:'Oum El Bouaghi', nameAr:'أم البواقي', communes:[{name:'Oum El Bouaghi',nameAr:'أم البواقي'}] },
    { name:'Ain Beida', nameAr:'عين البيضاء', communes:[{name:'Ain Beida',nameAr:'عين البيضاء'}] },
    { name:'Ain M\'lila', nameAr:'عين مليلة', communes:[{name:'Ain M\'lila',nameAr:'عين مليلة'}] },
    { name:'Ain Fakroun', nameAr:'عين فكرون', communes:[{name:'Ain Fakroun',nameAr:'عين فكرون'},{name:'Berriche',nameAr:'بريش'}] },
    { name:'Meskiana', nameAr:'مسكيانة', communes:[{name:'Meskiana',nameAr:'مسكيانة'}] },
  ]},
  { code:'05', name:'Batna', nameAr:'باتنة', shippingZone:'highland', dairas:[
    { name:'Batna', nameAr:'باتنة', communes:[{name:'Batna',nameAr:'باتنة'},{name:'Fesdis',nameAr:'فسديس'},{name:'Oued Chaaba',nameAr:'وادي الشعبة'}] },
    { name:'Barika', nameAr:'بريكة', communes:[{name:'Barika',nameAr:'بريكة'},{name:'Bitam',nameAr:'بيطام'}] },
    { name:'N\'Gaous', nameAr:'نقاوس', communes:[{name:'N\'Gaous',nameAr:'نقاوس'},{name:'Sefiane',nameAr:'سفيان'}] },
    { name:'Ain Touta', nameAr:'عين التوتة', communes:[{name:'Ain Touta',nameAr:'عين التوتة'},{name:'Hidoussa',nameAr:'هيدوسة'}] },
    { name:'Merouana', nameAr:'مروانة', communes:[{name:'Merouana',nameAr:'مروانة'},{name:'Oued El Ma',nameAr:'وادي الماء'}] },
    { name:'Arris', nameAr:'أريس', communes:[{name:'Arris',nameAr:'أريس'},{name:'Tighanimine',nameAr:'تيغانيمين'}] },
    { name:'Tazoult', nameAr:'تازولت', communes:[{name:'Tazoult',nameAr:'تازولت'}] },
  ]},
  { code:'06', name:'Béjaïa', nameAr:'بجاية', shippingZone:'north', dairas:[
    { name:'Béjaïa', nameAr:'بجاية', communes:[{name:'Béjaïa',nameAr:'بجاية'},{name:'Oued Ghir',nameAr:'وادي غير'},{name:'Toudja',nameAr:'توجة'}] },
    { name:'Akbou', nameAr:'أقبو', communes:[{name:'Akbou',nameAr:'أقبو'},{name:'Ighram',nameAr:'إغرام'},{name:'Chellata',nameAr:'شلاطة'}] },
    { name:'Kherrata', nameAr:'خراطة', communes:[{name:'Kherrata',nameAr:'خراطة'},{name:'Draa El Caid',nameAr:'ذراع القايد'}] },
    { name:'Sidi Aich', nameAr:'سيدي عيش', communes:[{name:'Sidi Aich',nameAr:'سيدي عيش'},{name:'El Kseur',nameAr:'القصر'}] },
    { name:'Amizour', nameAr:'أميزور', communes:[{name:'Amizour',nameAr:'أميزور'},{name:'Semaoun',nameAr:'سمعون'}] },
    { name:'Timezrit', nameAr:'تيمزريت', communes:[{name:'Timezrit',nameAr:'تيمزريت'},{name:'Souk El Ténine',nameAr:'سوق الاثنين'}] },
  ]},
  { code:'07', name:'Biskra', nameAr:'بسكرة', shippingZone:'highland', dairas:[
    { name:'Biskra', nameAr:'بسكرة', communes:[{name:'Biskra',nameAr:'بسكرة'},{name:'El Hadjeb',nameAr:'الحاجب'},{name:'Chetma',nameAr:'شتمة'}] },
    { name:'Tolga', nameAr:'طولقة', communes:[{name:'Tolga',nameAr:'طولقة'},{name:'Bouchagroun',nameAr:'بوشقرون'},{name:'Bordj Ben Azzouz',nameAr:'برج بن عزوز'}] },
    { name:'Sidi Okba', nameAr:'سيدي عقبة', communes:[{name:'Sidi Okba',nameAr:'سيدي عقبة'},{name:'El Haouch',nameAr:'الحوش'}] },
    { name:'Ouled Djellal', nameAr:'أولاد جلال', communes:[{name:'Ouled Djellal',nameAr:'أولاد جلال'},{name:'Doucen',nameAr:'الدوسن'}] },
    { name:'M\'chouneche', nameAr:'مشونش', communes:[{name:'M\'chouneche',nameAr:'مشونش'},{name:'Djemorah',nameAr:'جمورة'}] },
  ]},
  { code:'08', name:'Béchar', nameAr:'بشار', shippingZone:'south', dairas:[
    { name:'Béchar', nameAr:'بشار', communes:[{name:'Béchar',nameAr:'بشار'},{name:'Béchar Djedid',nameAr:'بشار الجديدة'}] },
    { name:'Kenadsa', nameAr:'القنادسة', communes:[{name:'Kenadsa',nameAr:'القنادسة'}] },
    { name:'Abadla', nameAr:'العبادلة', communes:[{name:'Abadla',nameAr:'العبادلة'},{name:'Erg Ferradj',nameAr:'عرق فراج'}] },
    { name:'Beni Ounif', nameAr:'بني ونيف', communes:[{name:'Beni Ounif',nameAr:'بني ونيف'}] },
  ]},
  { code:'09', name:'Blida', nameAr:'البليدة', shippingZone:'capital', dairas:[
    { name:'Blida', nameAr:'البليدة', communes:[{name:'Blida',nameAr:'البليدة'},{name:'Beni Mered',nameAr:'بني مراد'}] },
    { name:'Boufarik', nameAr:'بوفاريك', communes:[{name:'Boufarik',nameAr:'بوفاريك'},{name:'Oued El Alleug',nameAr:'وادي العلايق'},{name:'Guerrouaou',nameAr:'قرواو'}] },
    { name:'Bouinan', nameAr:'بوعينان', communes:[{name:'Bouinan',nameAr:'بوعينان'},{name:'Soumaa',nameAr:'الصومعة'},{name:'Chréa',nameAr:'الشريعة'}] },
    { name:'El Affroun', nameAr:'العفرون', communes:[{name:'El Affroun',nameAr:'العفرون'},{name:'Mouzaia',nameAr:'موزاية'},{name:'Chiffa',nameAr:'الشفة'}] },
    { name:'Ouled Yaïch', nameAr:'أولاد يعيش', communes:[{name:'Ouled Yaïch',nameAr:'أولاد يعيش'},{name:'Beni Tamou',nameAr:'بني تامو'}] },
    { name:'Larbaa', nameAr:'الأربعاء', communes:[{name:'Larbaa',nameAr:'الأربعاء'},{name:'Bouarfa',nameAr:'بوعرفة'}] },
  ]},
  { code:'10', name:'Bouira', nameAr:'البويرة', shippingZone:'north', dairas:[
    { name:'Bouira', nameAr:'البويرة', communes:[{name:'Bouira',nameAr:'البويرة'},{name:'Haizer',nameAr:'الهاشمية'}] },
    { name:'Lakhdaria', nameAr:'الأخضرية', communes:[{name:'Lakhdaria',nameAr:'الأخضرية'},{name:'Kadiria',nameAr:'قادرية'}] },
    { name:'Sour El Ghozlane', nameAr:'سور الغزلان', communes:[{name:'Sour El Ghozlane',nameAr:'سور الغزلان'},{name:'Bordj Okhriss',nameAr:'برج أخريص'}] },
    { name:'M\'chedallah', nameAr:'مشدالة', communes:[{name:'M\'chedallah',nameAr:'مشدالة'},{name:'Saharidj',nameAr:'صهاريج'}] },
    { name:'Ain Bessem', nameAr:'عين بسام', communes:[{name:'Ain Bessem',nameAr:'عين بسام'},{name:'Bir Ghbalou',nameAr:'بئر غبالو'}] },
  ]},
  { code:'11', name:'Tamanrasset', nameAr:'تمنراست', shippingZone:'south', dairas:[
    { name:'Tamanrasset', nameAr:'تمنراست', communes:[{name:'Tamanrasset',nameAr:'تمنراست'},{name:'Abalessa',nameAr:'أبلسة'}] },
    { name:'In Amguel', nameAr:'عين أمقل', communes:[{name:'In Amguel',nameAr:'عين أمقل'}] },
  ]},
  { code:'12', name:'Tébessa', nameAr:'تبسة', shippingZone:'highland', dairas:[
    { name:'Tébessa', nameAr:'تبسة', communes:[{name:'Tébessa',nameAr:'تبسة'},{name:'El Hammamet',nameAr:'الحمامات'}] },
    { name:'Birr El Ater', nameAr:'بئر العاتر', communes:[{name:'Birr El Ater',nameAr:'بئر العاتر'},{name:'El Meridj',nameAr:'المريج'}] },
    { name:'Cheria', nameAr:'الشريعة', communes:[{name:'Cheria',nameAr:'الشريعة'}] },
    { name:'El Aouinet', nameAr:'العوينات', communes:[{name:'El Aouinet',nameAr:'العوينات'}] },
    { name:'Morsott', nameAr:'مرسط', communes:[{name:'Morsott',nameAr:'مرسط'}] },
  ]},
  { code:'13', name:'Tlemcen', nameAr:'تلمسان', shippingZone:'north', dairas:[
    { name:'Tlemcen', nameAr:'تلمسان', communes:[{name:'Tlemcen',nameAr:'تلمسان'},{name:'Mansourah',nameAr:'منصورة'},{name:'Chetouane',nameAr:'شتوان'}] },
    { name:'Maghnia', nameAr:'مغنية', communes:[{name:'Maghnia',nameAr:'مغنية'},{name:'Hammam Boughrara',nameAr:'حمام بوغرارة'}] },
    { name:'Ghazaouet', nameAr:'الغزوات', communes:[{name:'Ghazaouet',nameAr:'الغزوات'},{name:'Nedroma',nameAr:'ندرومة'}] },
    { name:'Sebdou', nameAr:'سبدو', communes:[{name:'Sebdou',nameAr:'سبدو'},{name:'El Aricha',nameAr:'العريشة'}] },
    { name:'Remchi', nameAr:'الرمشي', communes:[{name:'Remchi',nameAr:'الرمشي'},{name:'Ain Youcef',nameAr:'عين يوسف'}] },
  ]},
  { code:'14', name:'Tiaret', nameAr:'تيارت', shippingZone:'highland', dairas:[
    { name:'Tiaret', nameAr:'تيارت', communes:[{name:'Tiaret',nameAr:'تيارت'},{name:'Meghila',nameAr:'مغيلة'}] },
    { name:'Sougueur', nameAr:'السوقر', communes:[{name:'Sougueur',nameAr:'السوقر'},{name:'Ain Deheb',nameAr:'عين الذهب'}] },
    { name:'Frenda', nameAr:'فرندة', communes:[{name:'Frenda',nameAr:'فرندة'},{name:'Ain Kermes',nameAr:'عين كرمس'}] },
    { name:'Mahdia', nameAr:'المهدية', communes:[{name:'Mahdia',nameAr:'المهدية'}] },
    { name:'Ksar Chellala', nameAr:'قصر الشلالة', communes:[{name:'Ksar Chellala',nameAr:'قصر الشلالة'}] },
  ]},
  { code:'15', name:'Tizi Ouzou', nameAr:'تيزي وزو', shippingZone:'north', dairas:[
    { name:'Tizi Ouzou', nameAr:'تيزي وزو', communes:[{name:'Tizi Ouzou',nameAr:'تيزي وزو'},{name:'Beni Zmenzer',nameAr:'بني زمنزر'}] },
    { name:'Azazga', nameAr:'عزازقة', communes:[{name:'Azazga',nameAr:'عزازقة'},{name:'Freha',nameAr:'فريحة'}] },
    { name:'Draa El Mizan', nameAr:'ذراع الميزان', communes:[{name:'Draa El Mizan',nameAr:'ذراع الميزان'},{name:'Tizi Gheniff',nameAr:'تيزي غنيف'}] },
    { name:'Ain El Hammam', nameAr:'عين الحمام', communes:[{name:'Ain El Hammam',nameAr:'عين الحمام'},{name:'Abi Youcef',nameAr:'أبي يوسف'}] },
    { name:'Larbaa Nath Irathen', nameAr:'لاربعاء ناث إيراثن', communes:[{name:'Larbaa Nath Irathen',nameAr:'لاربعاء ناث إيراثن'},{name:'Irdjen',nameAr:'إرجن'}] },
    { name:'Ouaguenoun', nameAr:'واقنون', communes:[{name:'Ouaguenoun',nameAr:'واقنون'},{name:'Tigzirt',nameAr:'تيقزيرت'}] },
    { name:'Beni Douala', nameAr:'بني دوالة', communes:[{name:'Beni Douala',nameAr:'بني دوالة'},{name:'Tizi Rached',nameAr:'تيزي راشد'}] },
    { name:'Boghni', nameAr:'بوغني', communes:[{name:'Boghni',nameAr:'بوغني'},{name:'Mechtras',nameAr:'مشطراس'}] },
  ]},
  { code:'16', name:'Alger', nameAr:'الجزائر', shippingZone:'capital', dairas:[
    { name:'Sidi M\'Hamed', nameAr:'سيدي امحمد', communes:[{name:'Sidi M\'Hamed',nameAr:'سيدي امحمد'},{name:'El Mouradia',nameAr:'المرادية'},{name:'Alger Centre',nameAr:'الجزائر الوسطى'},{name:'El Madania',nameAr:'المدنية'}] },
    { name:'Bab El Oued', nameAr:'باب الوادي', communes:[{name:'Bab El Oued',nameAr:'باب الوادي'},{name:'Casbah',nameAr:'القصبة'},{name:'Oued Koriche',nameAr:'وادي قريش'},{name:'Bologhine',nameAr:'بولوغين'}] },
    { name:'Hussein Dey', nameAr:'حسين داي', communes:[{name:'Hussein Dey',nameAr:'حسين داي'},{name:'Kouba',nameAr:'القبة'},{name:'Bachdjerrah',nameAr:'باش جراح'},{name:'El Magharia',nameAr:'المقرية'}] },
    { name:'Bir Mourad Raïs', nameAr:'بئر مراد رايس', communes:[{name:'Bir Mourad Raïs',nameAr:'بئر مراد رايس'},{name:'Hydra',nameAr:'حيدرة'},{name:'Birkhadem',nameAr:'بئر خادم'},{name:'El Biar',nameAr:'الأبيار'},{name:'Ben Aknoun',nameAr:'بن عكنون'}] },
    { name:'Bouzareah', nameAr:'بوزريعة', communes:[{name:'Bouzareah',nameAr:'بوزريعة'},{name:'Beni Messous',nameAr:'بني مسوس'},{name:'Dely Ibrahim',nameAr:'دالي إبراهيم'}] },
    { name:'Dar El Beïda', nameAr:'الدار البيضاء', communes:[{name:'Dar El Beïda',nameAr:'الدار البيضاء'},{name:'Bab Ezzouar',nameAr:'باب الزوار'},{name:'Bordj El Kiffan',nameAr:'برج الكيفان'},{name:'Mohammadia',nameAr:'المحمدية'},{name:'Rouiba',nameAr:'الرويبة'},{name:'Reghaia',nameAr:'الرغاية'}] },
    { name:'Draria', nameAr:'الدرارية', communes:[{name:'Draria',nameAr:'الدرارية'},{name:'El Achour',nameAr:'العاشور'},{name:'Douera',nameAr:'الدويرة'},{name:'Khraicia',nameAr:'خرايسية'}] },
    { name:'Baraki', nameAr:'براقي', communes:[{name:'Baraki',nameAr:'براقي'},{name:'Les Eucalyptus',nameAr:'الأوكاليبتوس'},{name:'Sidi Moussa',nameAr:'سيدي موسى'},{name:'Birtouta',nameAr:'بئرتوتة'}] },
    { name:'Chéraga', nameAr:'الشراقة', communes:[{name:'Chéraga',nameAr:'الشراقة'},{name:'Staoueli',nameAr:'سطاوالي'},{name:'Zeralda',nameAr:'زرالدة'},{name:'Souidania',nameAr:'سويدانية'},{name:'Ain Benian',nameAr:'عين البنيان'}] },
    { name:'Oued Smar', nameAr:'وادي السمار', communes:[{name:'Oued Smar',nameAr:'وادي السمار'},{name:'Bourouba',nameAr:'بوروبة'},{name:'El Harrach',nameAr:'الحراش'}] },
    { name:'Bir Touta', nameAr:'بئرتوتة', communes:[{name:'Ouled Chebel',nameAr:'أولاد شبل'},{name:'Tessala El Merdja',nameAr:'تسالة المرجة'}] },
  ]},
  { code:'17', name:'Djelfa', nameAr:'الجلفة', shippingZone:'highland', dairas:[
    { name:'Djelfa', nameAr:'الجلفة', communes:[{name:'Djelfa',nameAr:'الجلفة'},{name:'El Idrissia',nameAr:'الإدريسية'}] },
    { name:'Messaad', nameAr:'مسعد', communes:[{name:'Messaad',nameAr:'مسعد'},{name:'Guettara',nameAr:'القطارة'}] },
    { name:'Ain Oussara', nameAr:'عين وسارة', communes:[{name:'Ain Oussara',nameAr:'عين وسارة'},{name:'Benhar',nameAr:'بنهار'}] },
    { name:'Hassi Bahbah', nameAr:'حاسي بحبح', communes:[{name:'Hassi Bahbah',nameAr:'حاسي بحبح'}] },
    { name:'Dar Chioukh', nameAr:'دار الشيوخ', communes:[{name:'Dar Chioukh',nameAr:'دار الشيوخ'}] },
  ]},
  { code:'18', name:'Jijel', nameAr:'جيجل', shippingZone:'north', dairas:[
    { name:'Jijel', nameAr:'جيجل', communes:[{name:'Jijel',nameAr:'جيجل'},{name:'El Aouana',nameAr:'العوانة'}] },
    { name:'Taher', nameAr:'الطاهير', communes:[{name:'Taher',nameAr:'الطاهير'},{name:'El Ancer',nameAr:'العنصر'},{name:'Chahna',nameAr:'الشحنة'}] },
    { name:'El Milia', nameAr:'الميلية', communes:[{name:'El Milia',nameAr:'الميلية'},{name:'Sidi Marouf',nameAr:'سيدي معروف'}] },
    { name:'Texenna', nameAr:'تكسنة', communes:[{name:'Texenna',nameAr:'تكسنة'}] },
  ]},
  { code:'19', name:'Sétif', nameAr:'سطيف', shippingZone:'highland', dairas:[
    { name:'Sétif', nameAr:'سطيف', communes:[{name:'Sétif',nameAr:'سطيف'},{name:'Ain Arnat',nameAr:'عين أرنات'},{name:'Ouled Sidi Ahmed',nameAr:'أولاد سيدي أحمد'}] },
    { name:'El Eulma', nameAr:'العلمة', communes:[{name:'El Eulma',nameAr:'العلمة'},{name:'Guellal',nameAr:'قلال'}] },
    { name:'Ain Oulmene', nameAr:'عين ولمان', communes:[{name:'Ain Oulmene',nameAr:'عين ولمان'}] },
    { name:'Bougaa', nameAr:'بوقاعة', communes:[{name:'Bougaa',nameAr:'بوقاعة'},{name:'Bouandas',nameAr:'بوعنداس'}] },
    { name:'Ain El Kebira', nameAr:'عين الكبيرة', communes:[{name:'Ain El Kebira',nameAr:'عين الكبيرة'}] },
    { name:'Ain Azel', nameAr:'عين آزال', communes:[{name:'Ain Azel',nameAr:'عين آزال'}] },
  ]},
  { code:'20', name:'Saïda', nameAr:'سعيدة', shippingZone:'highland', dairas:[
    { name:'Saïda', nameAr:'سعيدة', communes:[{name:'Saïda',nameAr:'سعيدة'},{name:'Rebahia',nameAr:'الرباحية'}] },
    { name:'Ain El Hadjar', nameAr:'عين الحجر', communes:[{name:'Ain El Hadjar',nameAr:'عين الحجر'}] },
    { name:'Youb', nameAr:'يوب', communes:[{name:'Youb',nameAr:'يوب'},{name:'Sidi Boubekeur',nameAr:'سيدي بوبكر'}] },
  ]},
  ...Array.from({length:38}, (_, i) => {
    const codes: Record<number, {c:string,n:string,a:string,z:'north'|'highland'|'south'|'capital'}> = {
      21:{c:'21',n:'Skikda',a:'سكيكدة',z:'north'}, 22:{c:'22',n:'Sidi Bel Abbès',a:'سيدي بلعباس',z:'north'},
      23:{c:'23',n:'Annaba',a:'عنابة',z:'north'}, 24:{c:'24',n:'Guelma',a:'قالمة',z:'north'},
      25:{c:'25',n:'Constantine',a:'قسنطينة',z:'north'}, 26:{c:'26',n:'Médéa',a:'المدية',z:'highland'},
      27:{c:'27',n:'Mostaganem',a:'مستغانم',z:'north'}, 28:{c:'28',n:'M\'Sila',a:'المسيلة',z:'highland'},
      29:{c:'29',n:'Mascara',a:'معسكر',z:'north'}, 30:{c:'30',n:'Ouargla',a:'ورقلة',z:'south'},
      31:{c:'31',n:'Oran',a:'وهران',z:'north'}, 32:{c:'32',n:'El Bayadh',a:'البيض',z:'highland'},
      33:{c:'33',n:'Illizi',a:'إليزي',z:'south'}, 34:{c:'34',n:'Bordj Bou Arréridj',a:'برج بوعريريج',z:'highland'},
      35:{c:'35',n:'Boumerdès',a:'بومرداس',z:'capital'}, 36:{c:'36',n:'El Tarf',a:'الطارف',z:'north'},
      37:{c:'37',n:'Tindouf',a:'تيندوف',z:'south'}, 38:{c:'38',n:'Tissemsilt',a:'تيسمسيلت',z:'highland'},
      39:{c:'39',n:'El Oued',a:'الوادي',z:'south'}, 40:{c:'40',n:'Khenchela',a:'خنشلة',z:'highland'},
      41:{c:'41',n:'Souk Ahras',a:'سوق أهراس',z:'north'}, 42:{c:'42',n:'Tipaza',a:'تيبازة',z:'capital'},
      43:{c:'43',n:'Mila',a:'ميلة',z:'north'}, 44:{c:'44',n:'Aïn Defla',a:'عين الدفلى',z:'north'},
      45:{c:'45',n:'Naâma',a:'النعامة',z:'highland'}, 46:{c:'46',n:'Aïn Témouchent',a:'عين تموشنت',z:'north'},
      47:{c:'47',n:'Ghardaïa',a:'غرداية',z:'south'}, 48:{c:'48',n:'Relizane',a:'غليزان',z:'north'},
      49:{c:'49',n:'Timimoun',a:'تيميمون',z:'south'}, 50:{c:'50',n:'Bordj Badji Mokhtar',a:'برج باجي مختار',z:'south'},
      51:{c:'51',n:'Ouled Djellal',a:'أولاد جلال',z:'highland'}, 52:{c:'52',n:'Béni Abbès',a:'بني عباس',z:'south'},
      53:{c:'53',n:'In Salah',a:'عين صالح',z:'south'}, 54:{c:'54',n:'In Guezzam',a:'عين قزام',z:'south'},
      55:{c:'55',n:'Touggourt',a:'تقرت',z:'south'}, 56:{c:'56',n:'Djanet',a:'جانت',z:'south'},
      57:{c:'57',n:'El M\'Ghair',a:'المغير',z:'south'}, 58:{c:'58',n:'El Meniaa',a:'المنيعة',z:'south'},
    };
    const w = codes[i + 21];
    if (!w) return null;
    return {
      code: w.c, name: w.n, nameAr: w.a, shippingZone: w.z,
      dairas: [{ name: w.n, nameAr: w.a, communes: [{name: w.n, nameAr: w.a}] }]
    } as WilayaData;
  }).filter(Boolean) as WilayaData[],
];
