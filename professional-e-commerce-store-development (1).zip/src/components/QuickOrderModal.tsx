import React, { useState, useMemo, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { CustomerInfo, OrderInfo } from '../types';
import { wilayas, SHIPPING_COSTS, SHIPPING_LABELS } from '../data/algeriaData';

const emptyCustomer: CustomerInfo = { fullName: '', phone: '', email: '', wilaya: '', daira: '', commune: '', address: '', notes: '' };

const QuickOrderModal: React.FC = () => {
  const { quickOrderProduct, setQuickOrderProduct, formatPrice, theme, placeOrder, showNotification } = useStore();
  const isDark = theme === 'dark';

  const [activeImg, setActiveImg] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState<string | undefined>(undefined);
  const [selectedSize, setSelectedSize] = useState<string | undefined>(undefined);
  const [customer, setCustomer] = useState<CustomerInfo>(emptyCustomer);
  const [errors, setErrors] = useState<Partial<Record<keyof CustomerInfo, string>> & { color?: string; size?: string; receipt?: string }>({});
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [transferReceipt, setTransferReceipt] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<OrderInfo | null>(null);
  const touchStartX = useRef<number | null>(null);

  const product = quickOrderProduct;

  const selectedWilaya = useMemo(() => wilayas.find(w => w.nameAr === customer.wilaya), [customer.wilaya]);
  const shippingCost = selectedWilaya ? SHIPPING_COSTS[selectedWilaya.shippingZone] : 0;

  if (!product) return null;
  const images = product.images.length > 0 ? product.images : [''];
  const total = product.price * quantity + shippingCost;

  const close = () => {
    setQuickOrderProduct(null);
    setActiveImg(0); setQuantity(1); setSelectedColor(undefined); setSelectedSize(undefined);
    setCustomer(emptyCustomer); setErrors({}); setPaymentMethod('cod'); setTransferReceipt('');
    setConfirmedOrder(null); setIsProcessing(false);
  };

  const nextImg = () => setActiveImg(p => (p + 1) % images.length);
  const prevImg = () => setActiveImg(p => (p - 1 + images.length) % images.length);

  const onTouchStart = (e: React.TouchEvent) => { touchStartX.current = e.touches[0].clientX; };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null || images.length < 2) return;
    const delta = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(delta) > 40) { delta > 0 ? prevImg() : nextImg(); }
    touchStartX.current = null;
  };

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) { const r = new FileReader(); r.onloadend = () => { setTransferReceipt(r.result as string); setErrors(prev => ({ ...prev, receipt: undefined })); }; r.readAsDataURL(e.target.files[0]); }
  };

  const validate = (): boolean => {
    const e: typeof errors = {};
    if (!customer.fullName || customer.fullName.length < 3) e.fullName = 'الاسم يجب أن يكون 3 أحرف على الأقل';
    if (!customer.phone || !/^0[567]\d{8}$/.test(customer.phone)) e.phone = 'رقم هاتف غير صحيح (05/06/07 + 8 أرقام)';
    if (!customer.wilaya) e.wilaya = 'اختر الولاية';
    if (!customer.daira || customer.daira.length < 2) e.daira = 'أدخل اسم الدائرة';
    if (!customer.commune || customer.commune.length < 2) e.commune = 'أدخل اسم البلدية';
    if (!customer.address || customer.address.length < 5) e.address = 'العنوان قصير جداً';
    if (product.colors && product.colors.length > 0 && !selectedColor) e.color = 'يرجى اختيار اللون';
    if (product.sizes && product.sizes.length > 0 && !selectedSize) e.size = 'يرجى اختيار المقاس';
    if ((paymentMethod === 'transfer' || paymentMethod === 'baridimob') && !transferReceipt) e.receipt = 'يرجى رفع صورة وصل التحويل';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    setIsProcessing(true);
    setTimeout(() => {
      const orderId = `DZ-${new Date().getFullYear()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;
      const newOrder: OrderInfo = {
        orderId, customer,
        items: [{ product, quantity, selectedColor, selectedSize }],
        subtotal: product.price * quantity, discount: 0, shipping: shippingCost, total,
        paymentMethod, paymentProof: transferReceipt || undefined,
        date: new Date().toISOString(), status: 'new',
      };
      placeOrder(newOrder);
      setConfirmedOrder(newOrder);
      setIsProcessing(false);
      showNotification('تم استلام طلبك بنجاح ✓', 'success');
    }, 1200);
  };

  const inp = `w-full px-3 py-2.5 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary-500/50 ${isDark ? 'bg-dark-bg border border-dark-border text-dark-text placeholder-dark-text2' : 'bg-white border border-gray-200 text-gray-900 placeholder-gray-400'}`;
  const label = `block text-[10px] font-semibold mb-1 ${isDark ? 'text-dark-text2' : 'text-gray-600'}`;

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-3">
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={close} />
      <div className={`relative w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl shadow-2xl animate-scaleIn ${isDark ? 'bg-dark-card' : 'bg-white'}`}>
        <button onClick={close} className={`absolute top-3 z-10 w-8 h-8 rounded-full flex items-center justify-center ${isDark ? 'bg-dark-bg text-dark-text' : 'bg-gray-100 text-gray-600'}`} style={{ insetInlineEnd: '12px' }}>
          <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        {/* ═══ Success state ═══ */}
        {confirmedOrder ? (
          <div className="p-6 text-center">
            <div className="w-16 h-16 mx-auto rounded-full bg-green-100 flex items-center justify-center text-3xl mb-3">✅</div>
            <h2 className={`text-lg font-bold mb-1 ${isDark ? 'text-dark-text' : 'text-gray-900'}`}>تم تأكيد طلبك بنجاح!</h2>
            <p className={`text-xs mb-4 ${isDark ? 'text-dark-text2' : 'text-gray-500'}`}>رقم الطلب: <span className="font-mono font-bold text-primary-500">#{confirmedOrder.orderId}</span></p>
            <div className={`rounded-xl p-3 text-xs mb-4 text-start ${isDark ? 'bg-dark-bg' : 'bg-gray-50'}`}>
              <div className="flex justify-between mb-1"><span className={isDark ? 'text-dark-text2' : 'text-gray-500'}>المنتج</span><span className={isDark ? 'text-dark-text' : 'text-gray-900'}>{product.name} ×{quantity}</span></div>
              {selectedColor && <div className="flex justify-between mb-1"><span className={isDark ? 'text-dark-text2' : 'text-gray-500'}>اللون</span><span>{selectedColor}</span></div>}
              {selectedSize && <div className="flex justify-between mb-1"><span className={isDark ? 'text-dark-text2' : 'text-gray-500'}>المقاس</span><span>{selectedSize}</span></div>}
              <div className="flex justify-between font-bold pt-1 border-t mt-1"><span className={isDark ? 'text-dark-text' : 'text-gray-900'}>الإجمالي</span><span className="text-primary-500">{formatPrice(confirmedOrder.total)}</span></div>
            </div>
            <button onClick={close} className="w-full py-3 bg-primary-600 hover:bg-primary-700 text-white rounded-xl font-bold text-sm">تمام، إغلاق</button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4 p-5">
            {/* ═══ Gallery (swipeable) ═══ */}
            <div>
              <div className="relative aspect-square rounded-xl overflow-hidden bg-gray-100 mb-2 select-none" onTouchStart={onTouchStart} onTouchEnd={onTouchEnd}>
                <img src={images[activeImg]} alt={product.name} className="w-full h-full object-cover pointer-events-none" />
                {images.length > 1 && (
                  <>
                    <button onClick={prevImg} className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 bg-white/80 rounded-full flex items-center justify-center shadow text-xs">›</button>
                    <button onClick={nextImg} className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 bg-white/80 rounded-full flex items-center justify-center shadow text-xs">‹</button>
                    <div className="absolute bottom-2 inset-x-0 flex justify-center gap-1">
                      {images.map((_, i) => <span key={i} className={`w-1.5 h-1.5 rounded-full ${i === activeImg ? 'bg-white' : 'bg-white/50'}`} />)}
                    </div>
                  </>
                )}
              </div>
              {images.length > 1 && (
                <div className="flex gap-1.5 overflow-x-auto mb-3">
                  {images.map((img, i) => (
                    <button key={i} onClick={() => setActiveImg(i)} className={`w-12 h-12 rounded-lg overflow-hidden border-2 flex-shrink-0 transition-all ${i === activeImg ? 'border-primary-500' : (isDark ? 'border-dark-border opacity-50' : 'border-gray-200 opacity-50')}`}>
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}

              <h2 className={`text-base font-bold mb-1 ${isDark ? 'text-dark-text' : 'text-gray-900'}`}>{product.name}</h2>
              <div className="flex items-baseline gap-2 mb-3">
                <span className={`text-xl font-black ${isDark ? 'text-dark-text' : 'text-gray-900'}`}>{formatPrice(product.price)}</span>
                {product.originalPrice && <span className={`text-xs line-through ${isDark ? 'text-dark-text2' : 'text-gray-400'}`}>{formatPrice(product.originalPrice)}</span>}
              </div>

              {/* Colors (shown only if admin added any) */}
              {product.colors && product.colors.length > 0 && (
                <div className="mb-3">
                  <p className={label}>🎨 اللون {errors.color && <span className="text-red-500">— {errors.color}</span>}</p>
                  <div className="flex flex-wrap gap-2">
                    {product.colors.map((c, i) => (
                      <button key={i} type="button" onClick={() => { setSelectedColor(c.name); setErrors(p => ({...p, color: undefined})); }}
                        title={c.name}
                        className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${selectedColor === c.name ? 'border-primary-500 scale-110' : (isDark ? 'border-dark-border' : 'border-gray-200')}`}>
                        <span className="rounded-full block" style={{ backgroundColor: c.hex, width: '22px', height: '22px' }} />
                      </button>
                    ))}
                  </div>
                  {selectedColor && <p className={`text-[10px] mt-1 ${isDark ? 'text-dark-text2' : 'text-gray-500'}`}>المختار: {selectedColor}</p>}
                </div>
              )}

              {/* Sizes (shown only if admin added any) */}
              {product.sizes && product.sizes.length > 0 && (
                <div className="mb-3">
                  <p className={label}>📏 المقاس {errors.size && <span className="text-red-500">— {errors.size}</span>}</p>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((s, i) => (
                      <button key={i} type="button" onClick={() => { setSelectedSize(s); setErrors(p => ({...p, size: undefined})); }}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold border-2 transition-all ${selectedSize === s ? 'border-primary-500 bg-primary-50 text-primary-700 dark:bg-primary-900/20 dark:text-primary-400' : (isDark ? 'border-dark-border text-dark-text2' : 'border-gray-200 text-gray-600')}`}>
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity */}
              <div className="mb-2">
                <p className={label}>الكمية</p>
                <div className={`flex items-center gap-1 rounded-xl p-1 w-fit ${isDark ? 'bg-dark-bg' : 'bg-gray-50'}`}>
                  <button onClick={() => setQuantity(q => Math.max(1, q - 1))} className={`w-8 h-8 rounded-lg font-bold ${isDark ? 'bg-dark-card text-dark-text' : 'bg-white text-gray-600'}`}>−</button>
                  <span className={`w-8 text-center font-bold text-sm ${isDark ? 'text-dark-text' : 'text-gray-900'}`}>{quantity}</span>
                  <button onClick={() => setQuantity(q => q + 1)} className={`w-8 h-8 rounded-lg font-bold ${isDark ? 'bg-dark-card text-dark-text' : 'bg-white text-gray-600'}`}>+</button>
                </div>
              </div>
            </div>

            {/* ═══ Order form ═══ */}
            <div className="flex flex-col">
              <h3 className={`text-sm font-bold mb-3 ${isDark ? 'text-dark-text' : 'text-gray-900'}`}>📋 معلومات الطلب</h3>
              <div className="grid grid-cols-2 gap-2 mb-2">
                <div className="col-span-2">
                  <label className={label}>الاسم الكامل *</label>
                  <input type="text" value={customer.fullName} onChange={e => { setCustomer({...customer, fullName: e.target.value}); setErrors({...errors, fullName: undefined}); }} placeholder="الاسم الكامل" className={inp} />
                  {errors.fullName && <p className="text-red-500 text-[10px] mt-0.5">{errors.fullName}</p>}
                </div>
                <div className="col-span-2">
                  <label className={label}>رقم الهاتف *</label>
                  <input type="tel" value={customer.phone} onChange={e => { setCustomer({...customer, phone: e.target.value}); setErrors({...errors, phone: undefined}); }} placeholder="05/06/07XXXXXXXX" className={inp} dir="ltr" />
                  {errors.phone && <p className="text-red-500 text-[10px] mt-0.5">{errors.phone}</p>}
                </div>
                <div className="col-span-2">
                  <label className={label}>الولاية *</label>
                  <select value={customer.wilaya} onChange={e => { setCustomer({...customer, wilaya: e.target.value}); setErrors({...errors, wilaya: undefined}); }} className={`${inp} appearance-none`}>
                    <option value="">-- اختر الولاية --</option>
                    {wilayas.map(w => <option key={w.code} value={w.nameAr}>{w.code} - {w.nameAr}</option>)}
                  </select>
                  {errors.wilaya && <p className="text-red-500 text-[10px] mt-0.5">{errors.wilaya}</p>}
                  {selectedWilaya && <p className={`text-[10px] mt-0.5 ${isDark ? 'text-primary-400' : 'text-primary-600'}`}>🚚 توصيل: {SHIPPING_COSTS[selectedWilaya.shippingZone]} د.ج ({SHIPPING_LABELS[selectedWilaya.shippingZone]})</p>}
                </div>
                <div>
                  <label className={label}>الدائرة *</label>
                  <input type="text" value={customer.daira} onChange={e => { setCustomer({...customer, daira: e.target.value}); setErrors({...errors, daira: undefined}); }} placeholder="الدائرة" className={inp} />
                  {errors.daira && <p className="text-red-500 text-[10px] mt-0.5">{errors.daira}</p>}
                </div>
                <div>
                  <label className={label}>البلدية *</label>
                  <input type="text" value={customer.commune} onChange={e => { setCustomer({...customer, commune: e.target.value}); setErrors({...errors, commune: undefined}); }} placeholder="البلدية" className={inp} />
                  {errors.commune && <p className="text-red-500 text-[10px] mt-0.5">{errors.commune}</p>}
                </div>
                <div className="col-span-2">
                  <label className={label}>العنوان التفصيلي *</label>
                  <input type="text" value={customer.address} onChange={e => { setCustomer({...customer, address: e.target.value}); setErrors({...errors, address: undefined}); }} placeholder="الشارع، الحي، رقم المبنى" className={inp} />
                  {errors.address && <p className="text-red-500 text-[10px] mt-0.5">{errors.address}</p>}
                </div>
                <div className="col-span-2">
                  <label className={label}>ملاحظات (اختياري)</label>
                  <textarea value={customer.notes} onChange={e => setCustomer({...customer, notes: e.target.value})} placeholder="ملاحظات إضافية..." className={`${inp} resize-none`} rows={1} />
                </div>
              </div>

              {/* Payment method */}
              <p className={label}>💳 طريقة الدفع</p>
              <div className="space-y-1.5 mb-2">
                {[
                  { key: 'cod', icon: '💵', title: 'الدفع عند الاستلام' },
                  { key: 'transfer', icon: '🏦', title: 'تحويل بنكي CCP' },
                  { key: 'baridimob', icon: '📱', title: 'بريدي موب' },
                ].map(pm => (
                  <button key={pm.key} type="button" onClick={() => setPaymentMethod(pm.key)}
                    className={`w-full p-2 rounded-xl border-2 text-start flex items-center gap-2 text-xs transition-all ${paymentMethod === pm.key ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : (isDark ? 'border-dark-border' : 'border-gray-200')}`}>
                    <div className={`w-3.5 h-3.5 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${paymentMethod === pm.key ? 'border-primary-500' : (isDark ? 'border-dark-text2' : 'border-gray-300')}`}>
                      {paymentMethod === pm.key && <div className="w-1.5 h-1.5 rounded-full bg-primary-500" />}
                    </div>
                    <span>{pm.icon}</span>
                    <span className={`font-bold ${isDark ? 'text-dark-text' : 'text-gray-900'}`}>{pm.title}</span>
                  </button>
                ))}
              </div>

              {(paymentMethod === 'transfer' || paymentMethod === 'baridimob') && (
                <div className={`mb-2 p-2.5 rounded-xl animate-fadeIn text-[11px] ${isDark ? 'bg-dark-bg' : 'bg-gray-50'}`}>
                  <p className={isDark ? 'text-dark-text2' : 'text-gray-600'}>CCP: <span className="font-mono font-bold">0020006548 52</span></p>
                  <label className={`flex flex-col items-center justify-center w-full h-16 border-2 border-dashed rounded-xl cursor-pointer mt-1.5 ${isDark ? 'border-dark-border bg-dark-card' : 'border-gray-300 bg-white'}`}>
                    {transferReceipt ? <img src={transferReceipt} alt="" className="h-12 rounded-lg object-cover" /> : <span className={isDark ? 'text-dark-text2' : 'text-gray-500'}>📤 ارفع صورة وصل التحويل</span>}
                    <input type="file" accept="image/*" onChange={handleReceiptUpload} className="hidden" />
                  </label>
                  {transferReceipt && <p className="text-[10px] text-green-500 mt-1">✓ تم رفع الوصل بنجاح</p>}
                  {errors.receipt && <p className="text-[10px] text-red-500 mt-1">{errors.receipt}</p>}
                </div>
              )}

              <div className={`mt-auto pt-2 border-t-2 border-dashed ${isDark ? 'border-dark-border' : 'border-gray-200'}`}>
                <div className="flex justify-between items-center mb-2">
                  <span className={`text-sm font-bold ${isDark ? 'text-dark-text' : 'text-gray-900'}`}>الإجمالي</span>
                  <span className="text-lg font-black text-primary-500">{formatPrice(total)}</span>
                </div>
                <button onClick={handleSubmit} disabled={isProcessing} className="w-full py-3 bg-primary-600 hover:bg-primary-700 disabled:opacity-50 text-white rounded-xl font-bold text-sm flex items-center justify-center gap-2">
                  {isProcessing ? (<><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> جاري المعالجة...</>) : 'تأكيد الطلب الآن ✓'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuickOrderModal;
