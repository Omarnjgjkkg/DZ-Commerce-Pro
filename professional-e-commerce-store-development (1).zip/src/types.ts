export interface ProductColor {
  name: string;
  hex: string;
  image?: string;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  originalPrice?: number;
  images: string[];
  category: string;
  rating: number;
  reviews: number;
  badge?: string;
  inStock: boolean;
  soldCount?: number;
  stockCount?: number;
  colors?: ProductColor[];
  sizes?: string[];
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
}

export interface Review {
  id: string;
  productId: string;
  name: string;
  rating: number;
  comment: string;
  date: string;
}

export interface CustomerInfo {
  fullName: string;
  phone: string;
  email: string;
  wilaya: string;
  daira: string;
  commune: string;
  address: string;
  notes: string;
}

export interface OrderInfo {
  orderId: string;
  customer: CustomerInfo;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  paymentMethod: string;
  paymentProof?: string;
  date: string;
  status: 'new' | 'confirmed' | 'cancelled' | 'completed';
}

export interface StoreSettings {
  phone: string;
  email: string;
  ccpAccount: string;
  ccpKey: string;
  ripAccount: string;
  baridimobName: string;
  address: string;
  freeShippingMin: number;
  announcement: string;
}

export type Page = 'home' | 'admin' | 'cart' | 'checkout' | 'payment' | 'confirmation';
export type Category = 'الكل' | 'إلكترونيات' | 'أزياء' | 'إكسسوارات' | 'أجهزة منزلية';
export type ThemeMode = 'light' | 'dark';
export type Language = 'ar' | 'en' | 'fr';
export type CurrencyCode = 'SAR' | 'USD' | 'DZD';
export type CheckoutStep = 1 | 2 | 3 | 4;
